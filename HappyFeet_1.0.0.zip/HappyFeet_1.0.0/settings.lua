data:extend({
	{
		type = "string-setting",
		name = "tile-blacklist",
		setting_type = "runtime-per-user",
		default_value = "stone,stone-brick",
		order = "01"
	}
})
